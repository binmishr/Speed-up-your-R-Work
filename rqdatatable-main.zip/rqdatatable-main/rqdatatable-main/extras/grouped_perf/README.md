
Details for a small performance comparison run on 2020-01-02.

Article is here: http://www.win-vector.com/blog/2020/01/new-timings-for-a-grouped-in-place-aggregation-task/

R results: https://github.com/WinVector/rqdatatable/blob/master/extras/grouped_perf/grouped_performance.md
R DB results: https://github.com/WinVector/rqdatatable/blob/master/extras/grouped_perf/grouped_performance_db.md
Python results: https://github.com/WinVector/rqdatatable/blob/master/extras/grouped_perf/grouped_performance_data_algebra.md


Machine was an idle Late 2013 Mac Mini running macOS High Sierra 10.13.6, Processor 2.8 GHz Intel Core i5, Memory 8 GB 1600 MHz DDR3.

R version 3.6.0 (2019-04-26) -- "Planting of a Tree"

Python 3.7.5:
       Python 3.7.5 (default, Oct 25 2019, 10:52:18)
       [Clang 4.0.1 (tags/RELEASE_401/final)] :: Anaconda, Inc. on darwin

Pandas 0.25.3
numpy 1.17.3
data_algebra 0.4.3

